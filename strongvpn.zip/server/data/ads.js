module.exports = {
  AdsDumData: [
    {
      adsId: 'ca-app-pub-3940256099942544/6300978111',
      adsType: 'banner',
      adsPlatform: 'ios',
      adsStatus: false,
    },
    {
      adsId: 'ca-app-pub-3940256099942544/1033173712',
      adsType: 'interstitial',
      adsPlatform: 'ios',
      adsStatus: false,
    },
    {
      adsId: 'ca-app-pub-3940256099942544/5224354917',
      adsType: 'rewarded_video',
      adsPlatform: 'ios',
      adsStatus: false,
    },
    {
      adsId: 'ca-app-pub-3940256099942544/6300978111',
      adsType: 'banner',
      adsPlatform: 'android',
      adsStatus: false,
    },
    {
      adsId: 'ca-app-pub-3940256099942544/1033173712',
      adsType: 'interstitial',
      adsPlatform: 'android',
      adsStatus: false,
    },
    {
      adsId: 'ca-app-pub-3940256099942544/5224354917',
      adsType: 'rewarded_video',
      adsPlatform: 'android',
      adsStatus: false,
    },
  ]
}