var express = require('express');
var md5 = require('md5');
const { Admin } = require("../../models/admin");
const { Server } = require("../../models/server");
const { User } = require("../../models/user")
const { Package } = require("../../models/package")
const { api } = require("../../utils");
const router = express.Router();
const {
    checkSignin,
    checkExistAdmin,
    checkSignup,
    checkExistServer,
    checkExistIPServer,
    checkServer,
    checkUpdateProfile,
    checkExistIdAdmin,
    checkUpdatePassword,
    checkOldPassword,
    checkCreateAndUpdatePackage,
    checkCreateAndUpdateAds
  } = require("./middleware");
const { listview, filter, pagination } = require('../../utils/list');
const { Ads } = require('../../models/ads');
const { PackageDumData } = require('../../data/package');
const { AdsDumData } = require('../../data/ads');
  

/* IS NEW ADMIN? */
router.post('/admin/profile',[checkExistAdmin], async function(req, res, next) {
    const { isExistAdmin } = req;
    try {
        api.ok({
            res,
            data: isExistAdmin,
        });
      } catch (e) {
        api.error({ res });
      }
});

/* SIGNUP */
router.post('/admin/signup',[checkSignup, checkExistAdmin], async function(req, res, next) {
    const { body, isExistAdmin } = req;
    let admin = undefined;
    try {
        if (!isExistAdmin) {
            const admin = Admin.create({
                ...body,
                password: md5(body.password)
            })

            await Package.insertMany(PackageDumData)
            await Ads.insertMany(AdsDumData)
            api.ok({
                res,
                data: admin,
            });
        }else {
            
            api.error({ res });
        }
        
    } catch (e) {
        api.error({ res });
    }
});

/* SIGNIN */
router.post('/admin/signin',[checkSignin, checkExistAdmin], async function(req, res, next) {
    const { body: { password, email, ...props } = req, isExistAdmin } = req;
    let user = undefined;
    try {
        if (isExistAdmin) {
            user = await Admin.findOne({email, password: md5(password)})

            if (!user) {
                return api.error({ res }); 
            }

            return api.ok({
                res,
                data: user
            });
        }else {
            api.error({ res }); 
        }
        
    } catch (e) {
        api.error({ res });
    }
});

/* UPDATE PROFILE */
router.post('/admin/updateProfile',[checkUpdateProfile, checkExistIdAdmin], async function(req, res, next) {
    const { body: { adminId, ...props } = req, isExistIdAdmin } = req;
    try {
        if (isExistIdAdmin) {
            const admin = await Admin.findOneAndUpdate({_id: adminId}, props)
            api.ok({
                res,
                data: props,
            });
        }else {
            api.error({ res });
        }
        
    } catch (e) {
        api.error({ res });
    }
});

/* UPDATE PASSWORD */
router.post('/admin/updatePassword',[checkUpdatePassword, checkExistIdAdmin, checkOldPassword], async function(req, res, next) {
    const { body: { adminId, ...props } = req, isExistIdAdmin, isValidPassword } = req;
    try {
        if (isExistIdAdmin && isValidPassword) {
            const admin = await Admin.findOneAndUpdate({_id: adminId}, {password: md5(props.password)})
            api.ok({
                res,
                data: admin,
            });
        }else {
            api.error({ res });
        }
        
    } catch (e) {
        api.error({ res });
    }
});

/* GET SERVERS */
router.post('/admin/server', [checkExistIdAdmin, filter, pagination], async function(req, res, next) {
    const { isExistIdAdmin } = req;

    if (!isExistIdAdmin)  api.error({ res });
    
    return listview.get({ model: Server, res, next, req})
});
  
/* CREATE SERVERS */
router.post('/admin/createServer',[checkExistIdAdmin, checkServer, checkExistIPServer], async function(req, res, next) {
    const { body: { adminId, ...body }, isExistIPServer } = req;
    try {
        if (!isExistIPServer) {
            const server = await Server.create(body)
            api.ok({
                res,
                data: server,
            });
        }else {
            api.error({ res });
        }
        
    } catch (e) {
        api.error({ res });
    }
    
});


/* UPDATE SERVERS */
router.post('/admin/updateServer',[checkExistIdAdmin, checkServer, checkExistServer], async function(req, res, next) {
    const { body: { id, ...props } = req, isExistServer } = req;
    try {
        if (isExistServer) {
            const server = await Server.findOneAndUpdate({_id: id}, props)
            api.ok({
                res,
                data: server,
            });
        }else {
            api.error({ res });
        }
        
    } catch (e) {
        api.error({ res });
    }
});


/* DELETE SERVERS */
router.post('/admin/deleteServer',[checkExistIdAdmin, checkExistServer], async function(req, res, next) {
    const { body: { id, ...props } = req, isExistServer } = req;
    try {
        if (isExistServer) {
            const server = await Server.findOneAndDelete({_id: id})
            api.ok({
                res,
                data: true
            });
        }else {
            api.error({ res });
        }
        
    } catch (e) {
        api.error({ res });
    }
});


/* GET ALL USERS */
router.post('/admin/users',[checkExistIdAdmin, filter, pagination], async function(req, res, next) {
    const { isExistIdAdmin } = req;

    if (!isExistIdAdmin)  api.error({ res });
    
    return listview.get({ model: User, res, next, req})
});


/* GET DETAIL USER */
router.post('/admin/detailUser',[checkExistIdAdmin], async function(req, res, next) {
    const { body: { userId } = req, isExistIdAdmin } = req;
    try {
        if (isExistIdAdmin) {
            const user = await User.findById({_id: userId})
            api.ok({
                res,
                data: user
            });
        }else {
            api.error({ res });
        }
        
    } catch (e) {
        api.error({ res });
    }
});


/*  CREATE PACKAGE */
router.post('/admin/createPackage', [checkExistIdAdmin, checkCreateAndUpdatePackage], async function(req, res, next) {
    const { body: { id, ...props }, isExistIdAdmin } = req;
    try {
        if (isExistIdAdmin) {
            const package = await Package.create(props)

            api.ok({
                res,
                data: package
            });
        }else {
            api.error({ res });
        }
        
    } catch (e) {
        api.error({ res });
    }
});

/*  UPDATE PACKAGE */
router.put('/admin/updatePackage/:id', [checkExistIdAdmin, checkCreateAndUpdatePackage], async function(req, res, next) {
    const { id: packageId } = req.params

    if (!packageId) return api.error({ res });

    const { body: { id, ...props }, isExistIdAdmin } = req;
    try {
        if (isExistIdAdmin) {
            await Package.findByIdAndUpdate(packageId, props)

            api.ok({
                res,
                data: props
            });
        }else {
            api.error({ res });
        }
        
    } catch (e) {
        api.error({ res });
    }
});

/*  DELETE PACKAGE */
router.delete('/admin/deletePackage/:id', [checkExistIdAdmin], async function(req, res, next) {
    const { id: packageId } = req.params

    if (!packageId) return api.error({ res });

    const { isExistIdAdmin } = req;
    try {
        if (isExistIdAdmin) {
            await Package.findByIdAndDelete(packageId)

            api.ok({
                res,
                data: "success"
            });
        }else {
            api.error({ res });
        }
        
    } catch (e) {
        api.error({ res });
    }
});

/*  GET LIST PACKAGE*/
router.post('/admin/getPackage', [checkExistIdAdmin, filter, pagination], async function(req, res, next) {

    const { isExistIdAdmin } = req;

    if (!isExistIdAdmin)  api.error({ res });
    
    return listview.get({ model: Package, res, next, req})
});


/*  CREATE ADS */
router.post('/admin/createAdService', [checkExistIdAdmin, checkCreateAndUpdateAds], async function(req, res, next) {
    const { body: { id, ...props }, isExistIdAdmin } = req;
    try {
        if (isExistIdAdmin) {
            const ads = await Ads.create(props)

            api.ok({
                res,
                data: ads
            });
        }else {
            api.error({ res });
        }
        
    } catch (e) {
        api.error({ res });
    }
});

/*  UPDATE ADS */
router.put('/admin/updateAdService/:id', [checkExistIdAdmin, checkCreateAndUpdateAds], async function(req, res, next) {
    const { id: adsId } = req.params
    if (!adsId) return api.error({ res });

    const { body: { id, ...props }, isExistIdAdmin } = req;
    try {
        if (isExistIdAdmin) {
            await Ads.findByIdAndUpdate(adsId, props)

            api.ok({
                res,
                data: props
            });
        }else {
            api.error({ res });
        }
        
    } catch (e) {
        api.error({ res });
    }
});

/*  DELETE ADS */
router.delete('/admin/deleteAdService/:id', [checkExistIdAdmin], async function(req, res, next) {
    const { id: adsId } = req.params

    if (!adsId) return api.error({ res });

    const { isExistIdAdmin } = req;
    try {
        if (isExistIdAdmin) {
            await Ads.findByIdAndDelete(adsId)

            api.ok({
                res,
                data: "success"
            });
        }else {
            api.error({ res });
        }
        
    } catch (e) {
        api.error({ res });
    }
});

/*  GET LIST ADS*/
router.post('/admin/getAdService', [filter, pagination, checkExistIdAdmin], async function(req, res, next) {

    const { isExistIdAdmin } = req;

    if (!isExistIdAdmin)  api.error({ res });
    
    return listview.get({ model: Ads, res, next, req})
});


module.exports = router;
