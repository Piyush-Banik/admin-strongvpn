const Joi = require("@hapi/joi");
const { User } = require("../../../models/user");
const { api } = require("../../../utils");

const checkAuthByString = async (token, req, res, next) => {
  if (token) {
    const payload = verify(token);

    if (payload.id && payload.email) {
        const user = await User.findOne({ _id: payload.id, email: payload.email})
        if (!user) {
          api.unAuthorize({res});
        } else {
          req.user = user;

          next()
        }
    } else {
      api.unAuthorize({res});
    }
  } else {
    api.unAuthorize({res});
  }
};

const checkSignin = (req, res, next) => {
  const schema = Joi.object({
    email: Joi.string().email().lowercase().required(),
  });

  const valid = schema.validateAsync(req.body, { abortEarly: false });

  valid
    .then(() => next())
    .catch(() => {
      api.error({ res, message: "Sever has some problems!" });
    });
};

const checkExistUser = async (req, res, next) => {
  const {
    body: { email },
  } = req;

  try {
    const user = await User.findOne({ email });

    if (user && user.email === email) {
      req.isExistUser = true
    }

    return next();
  } catch (e){
    return api.error({ res});
  }
};

const checkOTP = (req, res, next) => {
  const schema = Joi.object({
    email: Joi.string().email().lowercase().required(),
    code: Joi.string().length(6).required(),
  });

  const valid = schema.validateAsync(req.body, { abortEarly: false });

  valid
    .then(() => next())
    .catch(() => {
      api.error({ res, message: "Sever has some problems!" });
    });
};

const checkProfile = (req, res, next) => {
  const schema = Joi.object({
    email: Joi.string().email().lowercase().required(),
    id: Joi.string().required(),
  });

  const valid = schema.validateAsync(req.body, { abortEarly: false });

  valid
    .then(() => next())
    .catch(() => {
      api.error({ res, message: "Sever has some problems!" });
    });
}

const checkAnonymousUser = async (req, res, next) => {
  const { deviceId } = req.body;


  if (!deviceId) return api.error({ res });

  try {
    const user = await User.findOne({deviceId, isAnonymous: true})

    if (!user) return next()

    return api.ok({res, data: user})
  } catch(err) {
    return api.error({ res });
  }
}

const updateTotalDownloadAndUpload = async (req, res, next) => {
  const schema = Joi.object({
    userId: Joi.string().required(),
    totalUpload: Joi.number().default(0),
    totalDownload: Joi.number().default(0),
  });

  const valid = schema.validateAsync(req.body, { abortEarly: false });

  valid
    .then(() => next())
    .catch(() => {
      api.error({ res, message: "Sever has some problems!" });
    });
}

const checkExistUserById = async (req, res, next) => {
  const {
    body: { userId },
  } = req;

  try {
    const user = await User.findById(userId)

    if (!user) return api.error({ res });

    req.user = user;
 
    return next();
  } catch (e){
    return api.error({ res});
  }
};

module.exports = {
  checkOTP,
  checkSignin,
  checkExistUser,
  checkProfile,
  checkAuthByString,
  checkAnonymousUser,
  updateTotalDownloadAndUpload,
  checkExistUserById,
};
