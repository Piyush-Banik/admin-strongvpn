import {Form, Input, notification, Select} from "antd";
import UICPopup from "@app/components/core/popup/cpopup";
import React from "react";
import * as Yup from "yup";
import CurrencyFormat from 'react-currency-format';
import {Formik} from "formik";
import UIButton from "@app/components/core/button";
import {removeError} from "@app/utils";

export const PackDetail = ({onClose, cb, data = undefined}) => {
  const [formData, setFormData] = React.useState({
    packageName: undefined,
    packagePricing: undefined,
    platform: undefined,
    packageId: undefined,
    duration: undefined,
  });

  const validateSchema = Yup.object({
    packagePricing: Yup.number().required("Please input pricing"),
    packageId: Yup.string().required("Please input purchase id"),
    packageName: Yup.string().required("Please input package name"),
    duration: Yup.string().required("Please choose duration"),
  });

  React.useEffect(() => {
    if (data) {
      setFormData({
        packageName: data?.packageName,
        packagePricing: data?.packagePricing,
        duration: data?.duration,
        platform: data?.platform,
        packageId: data?.packageId,
      });
    }
  }, []);

  const update = (form) => {
    // if (!data?.id) return
    // firestore.collection("packages").doc(data?.id).set(form).then((data) => {
    //   notification.info({
    //     description: `Package was updated successfully`,
    //     placement: "bottomRight",
    //     duration: 2,
    //     icon: "",
    //     className: "core-notification info",
    //   });
    //   onClose()
    //   cb()
    // })
    //   .catch((err) => {
    //     notification.info({
    //       description: `Package was updated failure`,
    //       placement: "bottomRight",
    //       duration: 2,
    //       icon: "",
    //       className: "core-notification error",
    //     });
    //   })
  }

  return (
    <UICPopup
      hiddenFooter={true}
      onCancel={onClose}
      textCancel="Cancel"
      textOk="Save"
      title={`${data ? "Update" : "New"} Pack`}
      width={416}
    >
      <Formik
        onSubmit={(e) => {
          update(e);
        }}
        validationSchema={validateSchema}
        initialValues={formData}
        enableReinitialize
      >
        {({setErrors, setFieldValue, errors, values, handleSubmit}) => {

          return (
            <Form onFinish={handleSubmit} className="block w-full">
              <Form.Item
                hasFeedback={!!errors["packageName"]}
                validateStatus={errors["packageName"] && "error"}
                help={errors["packageName"]}
                className="core-form-item w-full mb-2 block"
                label="Pack name"
              >
                <Input
                  onChange={({target: {value}}) => {
                    setFieldValue("packageName", value, false);
                    removeError({
                      errors,
                      name: "packageName",
                      setErrors,
                    });
                  }}
                  placeholder="Pack name"
                  value={values?.packageName}
                  className="w-full"
                />
              </Form.Item>
              <Form.Item
                hasFeedback={!!errors["packagePricing"]}
                validateStatus={errors["packagePricing"] && "error"}
                help={errors["packagePricing"]}
                className="core-form-item w-full mb-2 block"
                label="pricing"
              >
                <CurrencyFormat
                  style={{padding: '4px 11px'}}
                  thousandSeparator={true}
                  prefix={'$'}
                  onValueChange={({formattedValue, value}) => {
                    setFieldValue("packagePricing", parseFloat(value) || 0, false);
                    removeError({
                      errors,
                      name: "packagePricing",
                      setErrors,
                    });
                  }}
                  placeholder="Pricing"
                  value={values?.packagePricing}
                  className="w-full"
                />
              </Form.Item>
              <Form.Item
                hasFeedback={!!errors["duration"]}
                validateStatus={errors["duration"] && "error"}
                help={errors["duration"]}
                className="core-form-item w-full mb-2 block"
                label="Duration"
              >
                <Select
                  disabled
                  // onChange={(value) => {
                  //   setFieldValue("duration", value, false)
                  //   removeError({
                  //     errors,
                  //     name: "duration",
                  //     setErrors,
                  //   });
                  // }}
                  placeholder="Duration" value={values?.duration} className="w-full">
                  <Select.Option value={""}>Choose</Select.Option>
                  {
                    values?.platform === "iOS"
                      ? (
                        <>
                          <Select.Option value={"1 Week"}>1 Week</Select.Option>
                          <Select.Option value={"1 Month"}>1 Month</Select.Option>
                          <Select.Option value={"2 Months"}>2 Months</Select.Option>
                          <Select.Option value={"3 Months"}>3 Months</Select.Option>
                          <Select.Option value={"6 Months"}>6 Months</Select.Option>
                          <Select.Option value={"1 Year"}>1 Year</Select.Option>
                        </>
                      )
                      : (
                        <>
                          <Select.Option value={"Weekly"}>Weekly</Select.Option>
                          <Select.Option value={"Every 4 weeks"}>Every 4 weeks</Select.Option>
                          <Select.Option value={"Monthly"}>Monthly</Select.Option>
                          <Select.Option value={"Every 3 months"}>Every 3 months</Select.Option>
                          <Select.Option value={"Every 6 months"}>Every 6 months</Select.Option>
                          <Select.Option value={"Yearly"}>Yearly</Select.Option>
                        </>
                      )
                  }
                </Select>
              </Form.Item>
              <Form.Item
                hasFeedback={!!errors["packageId"]}
                validateStatus={errors["packageId"] && "error"}
                help={errors["packageId"]}
                className="core-form-item w-full mb-2 block"
                label="purchase id"
              >
                <Input
                  onChange={({target: {value}}) => {
                    setFieldValue("packageId", value, false);
                    removeError({
                      errors,
                      name: "packageId",
                      setErrors,
                    });
                  }}
                  placeholder="Purchase id"
                  value={values?.packageId}
                  className="w-full"
                />
              </Form.Item>
              <Form.Item
                hasFeedback={!!errors["platform"]}
                validateStatus={errors["platform"] && "error"}
                help={errors["platform"]}
                className="core-form-item w-full mb-2 block"
                label="Os"
              >
                <Select
                  disabled
                  placeholder="Os" value={values?.platform} className="w-full">
                  <Select.Option value={"Android"}>Android</Select.Option>
                  <Select.Option value={"iOS"}>iOS</Select.Option>
                </Select>
              </Form.Item>
              <div className="flex justify-end pt-4 border-0 border-t border-solid border-gray-200">
                <UIButton onClick={onClose} className="ghost border mr-4">
                  Cancel
                </UIButton>
                <UIButton
                  htmlType="submit"
                  className="third"
                >
                  Save
                </UIButton>
              </div>
            </Form>
          );
        }}
      </Formik>
    </UICPopup>
  );
}
